' Deep Reef — original deterministic simulation helpers. Double precision PRNG arithmetic.
function ReefClamp(v as double, lo as double, hi as double) as double
    if v < lo then return lo
    if v > hi then return hi
    return v
end function

function ReefWrap(v as double, period as double) as double
    return v - Int(v / period) * period
end function

function ReefRandom(s as object) as double
    v = s.rng * 48271#
    s.rng = v - Int(v / 2147483647#) * 2147483647#
    return (s.rng - 1#) / 2147483646#
end function

function ReefRange(s as object, lo as double, hi as double) as double
    return lo + ReefRandom(s) * (hi - lo)
end function

function ReefAngle(x as double, z as double) as double
    if Abs(x) < 0.00001
        if z >= 0 then return 1.570796327#
        return -1.570796327#
    end if
    a = Atn(z / x)
    if x < 0 then a = a + 3.141592654
    return a * 1#
end function

function ReefAngleDelta(a as double, b as double) as double
    return ReefWrap(b - a + 3.141592654, 6.283185307) - 3.141592654
end function

function ReefEase(v as double) as double
    v = ReefClamp(v, 0, 1)
    return v * v * (3 - 2 * v)
end function

function ReefRGBA(r as integer, g as integer, b as integer, a as integer) as integer
    if r > 127 then r = r - 256
    return r * &h1000000 + g * &h10000 + b * &h100 + a
end function

function ReefMin(a as double, b as double) as double
    if a < b then return a
    return b
end function

function ReefMax(a as double, b as double) as double
    if a > b then return a
    return b
end function

function ReefFrameSchedule(nowMs as double, deadline as double, fps as double) as object
    deadline = deadline + 1000# / fps
    if deadline < nowMs then deadline = nowMs
    ' A double-buffered swap supplies native display pacing at 60Hz.
    ' Only the 30Hz mode needs an extra wait; leave GPU submission headroom.
    delay = 0
    if fps < 59 then delay = Int(ReefMax(0#, deadline - nowMs - 8#))
    return {deadline:deadline, sleepMs:delay}
end function

' Integer draw coordinates plus a large pretranslation and floating-point scale
' retain fractional placement. Scale error across a 2048px layer stays below 1/32px.
function ReefLayerTransform(x as double, y as double, sx as double, sy as double, result = invalid as dynamic) as object
    anchor = 65536#
    px = Int(x - anchor * sx)
    py = Int(y - anchor * sy)
    if result = invalid then result = {}
    result.x = px : result.y = py
    result.sx = (x - px) / anchor : result.sy = (y - py) / anchor
    return result
end function

function ReefFractionalPixelsValid(pixels as object) as boolean
    if pixels.Count() <> 1536 then return false
    ' Accept RGB/BGRA/ARGB readback layouts; a constant alpha channel cannot pass.
    for channel = 0 to 3
        totalA = 0# : totalB = 0# : weightedA = 0# : weightedB = 0#
        for column = 0 to 23
            a = pixels[(4 * 24 + column) * 4 + channel]
            b = pixels[(11 * 24 + column) * 4 + channel]
            totalA = totalA + a : totalB = totalB + b
            weightedA = weightedA + column * a : weightedB = weightedB + column * b
        end for
        if totalA >= 128 and totalB >= 128
            centerA = weightedA / totalA
            centerB = weightedB / totalB
            movement = Abs(centerB - centerA)
            ' Readback can be vertically flipped or use a half-texel convention.
            if ReefMin(centerA,centerB) > 8.25 and ReefMax(centerA,centerB) < 9.75 and movement > 0.12 and movement < 0.45 then return true
        end if
    end for
    return false
end function
